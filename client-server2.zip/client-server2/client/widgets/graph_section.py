from PyQt6.QtWidgets import (
    QWidget, QGroupBox, QVBoxLayout, QPushButton, QHBoxLayout, QComboBox
)
from payload.distance import RelativeDistancePlotter
from payload.relative_angle import RelativeAnglePlotter
from payload.spin import AngularPositionPlotter
import time

class GraphSection(QGroupBox):
    def __init__(self, record_btn: QPushButton, duration_dropdown: QComboBox, parent=None):
        super().__init__("Graph Display", parent)
        self.setObjectName("GraphSection")

        self.setStyleSheet("""
            QGroupBox {
                border: 1px solid #888;
                border-radius: 8px;
                background: #222;
            }
        """)

        self.graph_display_layout = QVBoxLayout()
        self.setLayout(self.graph_display_layout)

        self.graph_display_placeholder = QWidget()
        self.placeholder_layout = QVBoxLayout(self.graph_display_placeholder)
        self.placeholder_layout.setContentsMargins(10, 10, 10, 10)
        self.placeholder_layout.setSpacing(15)

        self.graph_modes = ["Relative Distance", "Relative Angle", "Angular Position"]
        self.select_buttons = {}

        for mode in self.graph_modes:
            btn = QPushButton(mode)
            btn.setMinimumHeight(60)
            btn.setStyleSheet("""
                QPushButton {
                    font-size: 16px;
                    background-color: #444;
                    color: white;
                    border: 2px solid #888;
                    border-radius: 6px;
                }
                QPushButton:hover {
                    background-color: #666;
                }
            """)
            btn.clicked.connect(lambda _, m=mode: self.load_graph(m))
            self.placeholder_layout.addWidget(btn)
            self.select_buttons[mode] = btn

        self.graph_display_layout.addWidget(self.graph_display_placeholder)

        self.record_btn = record_btn
        self.duration_dropdown = duration_dropdown
        self.graph_widget = None
        self.exit_graph_btn = None
        self.shared_start_time = None

    def load_graph(self, mode):
        self.graph_display_placeholder.setParent(None)

        if mode == "Relative Distance":
            self.graph_widget = RelativeDistancePlotter()
        elif mode == "Relative Angle":
            self.graph_widget = RelativeAnglePlotter()
        elif mode == "Angular Position":
            self.graph_widget = AngularPositionPlotter()
        else:
            return

        self.shared_start_time = time.time()
        self.graph_widget.start_time = self.shared_start_time
        self.graph_widget.setFixedHeight(230)
        self.graph_display_layout.addWidget(self.graph_widget)

        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(10)
        btn_layout.addWidget(self.record_btn)
        btn_layout.addWidget(self.duration_dropdown)

        self.exit_graph_btn = QPushButton("← Back")
        self.exit_graph_btn.setMinimumHeight(self.record_btn.minimumHeight())
        self.exit_graph_btn.setMaximumHeight(self.record_btn.maximumHeight())
        self.exit_graph_btn.setStyleSheet("""
            QPushButton {
                font-size: 9pt;
                background-color: #222;
                color: white;
                border: 1px solid #888;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #444;
            }
        """)
        self.exit_graph_btn.clicked.connect(self.exit_graph)
        btn_layout.addWidget(self.exit_graph_btn)

        self.exit_graph_btn.setSizePolicy(self.record_btn.sizePolicy())
        self.graph_display_layout.addLayout(btn_layout)

    def exit_graph(self):
        if self.graph_widget:
            self.graph_widget.setParent(None)
            self.graph_widget = None
        if self.exit_graph_btn:
            self.exit_graph_btn.setParent(None)
        self.record_btn.setParent(None)
        self.duration_dropdown.setParent(None)
        self.graph_display_layout.addWidget(self.graph_display_placeholder)
