from PyQt6.QtWidgets import QGroupBox, QVBoxLayout, QLabel
from PyQt6.QtCore import Qt


class DetectorOutputWidget(QGroupBox):
    def __init__(self):
        super().__init__("Detector Output")
        self.layout = QVBoxLayout()
        self.setLayout(self.layout)
        self.label = QLabel(alignment=Qt.AlignmentFlag.AlignCenter)
        self.label.setFixedSize(384, 216)
        self.label.setStyleSheet("background: #222; border: 1px solid #888;")
        self.layout.addWidget(self.label)
