from PyQt6.QtWidgets import QGroupBox, QVBoxLayout, QPushButton


class DetectorControlWidget(QGroupBox):
    def __init__(self):
        super().__init__("Detection Control")
        self.layout = QVBoxLayout()
        self.setLayout(self.layout)
        self.detector_btn = QPushButton("Start Detector")
        self.detector_btn.setEnabled(False)
        self.layout.addWidget(self.detector_btn)
