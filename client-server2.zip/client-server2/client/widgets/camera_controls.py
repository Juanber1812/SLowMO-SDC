from PyQt6.QtWidgets import QWidget, QGridLayout, QPushButton, QGroupBox

class CameraControlsWidget(QGroupBox):
    def __init__(self, parent=None):
        super().__init__("Camera Controls", parent)
        self.setObjectName("CameraControls")

        self.layout = QGridLayout()
        self.setLayout(self.layout)

        # Buttons
        self.toggle_btn = QPushButton("Start Stream")
        self.reconnect_btn = QPushButton("Reconnect")
        self.capture_btn = QPushButton("Capture Image")
        self.crop_btn = QPushButton("Crop")

        # Default states
        self.toggle_btn.setEnabled(False)
        self.capture_btn.setEnabled(False)
        self.crop_btn.setEnabled(False)

        # Add to layout
        self.layout.addWidget(self.toggle_btn, 0, 0)
        self.layout.addWidget(self.reconnect_btn, 0, 1)
        self.layout.addWidget(self.capture_btn, 1, 0)
        self.layout.addWidget(self.crop_btn, 1, 1)

        self.setStyleSheet("""
            QGroupBox {
                border: 1px solid #888;
                border-radius: 8px;
                background: #222;
            }
        """)
